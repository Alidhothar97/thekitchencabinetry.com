<?php
/**
 * Plugin Name:unlimited woo-commerce product variation by Ali Hassan
 * Description: Add unlimited product varation WooCommerce on Your demand.
 * Author: ALi Hassan <alidhothar97@gmail.com>
 * Author URI: https://web.facebook.com/profile.php?id=100009406373309
 * Version: 1.0.2
 */

/**
 * Copyright 2022 Ali Hassan  (email: alidhothar97@gmail.com)
 */
 
 function custom_wc_ajax_variation_threshold( $qty, $product ) {
	return 1500;
}

add_filter( 'woocommerce_ajax_variation_threshold', 'custom_wc_ajax_variation_threshold',100,15);
 ?>